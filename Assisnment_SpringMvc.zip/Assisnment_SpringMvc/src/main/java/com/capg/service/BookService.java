package com.capg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capg.model.Book;
import com.capg.repository.BookRepo;

@Service
@Transactional
public class BookService {
	
	@Autowired
	BookRepo bookrepo;
	
	public void addBook(Book book) {
		bookrepo.save(book);
		System.out.println("book added in db");
	}
	
	public List<Book> getAllBooks(){
		return bookrepo.findAll();
	}
	
	public Book findByBookId(int bid) {
		Book book = bookrepo.getOne(bid);
		System.out.println("inside service"+book.getBookName());
		return book;
	}
	
	public void updateBook(Book b) {
		Book oldbook = bookrepo.getOne(b.getBookId());
		b.setLibrary(oldbook.getLibrary());
		bookrepo.save(b);
	}
	
	public void deleteBookById(int bid) {
		bookrepo.deleteById(bid);
	}
	
	public void deleteBookByLibId(int lid) {
		List<Book> books = bookrepo.deleteAllBookByLibraryId(lid);
		
		for(Book b : books) {
			//System.out.println(b.getBookName()+"=============================================================");
			bookrepo.delete(b);
			//System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
			
		}
	}
}
