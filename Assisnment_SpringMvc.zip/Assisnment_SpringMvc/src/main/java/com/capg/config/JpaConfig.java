package com.capg.config;

import java.util.Properties;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

  @Configuration 
  @ComponentScan("com.capg")
  @EnableTransactionManagement 
  @EnableJpaRepositories(basePackages = {"com.capg.repository"})
  public class JpaConfig {

  
  @Bean 
  public DataSource dataSource() { 
	  DriverManagerDataSource dataSource = new DriverManagerDataSource();
	  
	  	dataSource.setDriverClassName("com.mysql.cj.jdbc.Driver");
	    dataSource.setUrl("jdbc:mysql://127.0.0.2:3306/nil");
	    dataSource.setUsername("root");
	    dataSource.setPassword("mySql@12345");

	  
	  return dataSource; 
	  
  }
  
  @Bean
  public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
  final LocalContainerEntityManagerFactoryBean entityManagerFactoryBean = new LocalContainerEntityManagerFactoryBean();
  entityManagerFactoryBean.setDataSource(dataSource());
  entityManagerFactoryBean.setPackagesToScan(new String[] { "com.capg.model"
  });
  
  final HibernateJpaVendorAdapter vendorAdapter = new
  HibernateJpaVendorAdapter();
  entityManagerFactoryBean.setJpaVendorAdapter(vendorAdapter);
  entityManagerFactoryBean.setJpaProperties(additionalProperties());
  
  return entityManagerFactoryBean;
  
  }
  
   Properties additionalProperties() {
	  Properties hibernateProperties = new Properties();
  
	  hibernateProperties.setProperty("hibernate.hbm2ddl.auto", "update");
	  hibernateProperties.setProperty("hibernate.dialect","org.hibernate.dialect.MySQL5Dialect");
	  hibernateProperties.setProperty("hibernate.show_sql", "true");
	  hibernateProperties.setProperty("hibernate.format_sql", "true");
  
	  return hibernateProperties;
  }
  
  	@Bean
	public PlatformTransactionManager transactionManager(EntityManagerFactory emf) {
		JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(emf);

		return transactionManager;
	}
  
  
  @Bean 
  public PersistenceExceptionTranslationPostProcessor
  exceptionTranslation(){ return new
  PersistenceExceptionTranslationPostProcessor(); }
  
  }
 