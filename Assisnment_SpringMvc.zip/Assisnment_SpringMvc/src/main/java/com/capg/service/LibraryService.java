package com.capg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capg.model.Library;
import com.capg.repository.LibraryRepo;

@Service
@Transactional
public class LibraryService {
	
	@Autowired
	LibraryRepo libRepo;
	
	@Autowired
	BookService bookService;
	
	public void addLibrary(Library library) {
		libRepo.save(library);
		System.out.println("library added");
	}
	
	public List<Library> getAllLibrary(){
		return libRepo.findAll();
	}
	
	public List<String> getAllLibraryName(){
		return libRepo.getAllLibraryname();
	}
	
	public Library getLibraryByName(String name) {
		return libRepo.findByLibraryname(name);
	}
	
	public Library findById(int lid) {
		Library lib = libRepo.getOne(lid);
		System.out.println(lib.getLibraryName() +" inside service");
		return lib;
	}
	
	public void updateLibrary(Library lib) {
		Library oldLibrary = findById(lib.getLibraryId());
		lib.setBooks(oldLibrary.getBooks());
		libRepo.save(lib);
	}
	
	public void deleteLibrary(int lid) {
		bookService.deleteBookByLibId(lid);
		libRepo.deleteById(lid);
	}
}
