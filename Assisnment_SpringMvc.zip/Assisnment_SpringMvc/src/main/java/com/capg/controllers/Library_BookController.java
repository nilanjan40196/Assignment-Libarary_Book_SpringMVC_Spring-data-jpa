package com.capg.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capg.model.Book;
import com.capg.model.Library;
import com.capg.service.BookService;
import com.capg.service.LibraryService;

@Controller
public class Library_BookController {
	
	@Autowired
	LibraryService libService;
	
	@Autowired
	private BookService bookService;
	
	@RequestMapping("/add")
	public ModelAndView welcome() {
		ModelAndView mv = new ModelAndView();
		//mv.addObject("name", name);
		mv.setViewName("home");
		
		return mv;
	}
	
	@RequestMapping("/")
	public ModelAndView getAllLib() {
		System.out.println("home");
		List<Library> libraries = libService.getAllLibrary();
		List<Book> books = bookService.getAllBooks();
		ModelAndView mv = new ModelAndView();
		mv.addObject("libs", libraries);
		mv.addObject("books", books);
		mv.setViewName("index");
		//System.out.println(libraries.size());
		return mv;
	}
	
	
	@RequestMapping("/newLibrary")
	public ModelAndView getAddLibrary() {
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("AddLib");
		return mv;
	}
	
	@RequestMapping(value = "/addLib" , method = RequestMethod.POST )
	public String addLibrary(@ModelAttribute Library library) {
		System.out.println("Inside");
		libService.addLibrary(library);
		
		return "redirect:/";
	}
	
	@RequestMapping("/newBook")
	public ModelAndView getAddBook() {
		ModelAndView mv = new ModelAndView();
		List<String> libNames = libService.getAllLibraryName();
		mv.addObject("libNames", libNames);
		mv.setViewName("AddBook");
		System.out.println(libNames);
		return mv;
	}
	
	@RequestMapping(value = "/addBook" ,method = RequestMethod.POST)
	public String addBook(@ModelAttribute Book book,@RequestParam("libraryName") String lname) {
		
		Library library = libService.getLibraryByName(lname);
		//System.out.println(library.getLibraryId());
		book.setLibrary(library);
		bookService.addBook(book);
		
		return "redirect:/";
	}
	
	@RequestMapping("/getEditBook")
	public ModelAndView getEditBook(@RequestParam("id") int bid) {
		ModelAndView mv = new ModelAndView();
		//System.out.println(bid);
		Book book = bookService.findByBookId(bid);
		mv.addObject("b", book);
		mv.setViewName("EditBook");
		System.out.println(book.getBookName());
		return mv;
		
	}
	
	@RequestMapping(value = "/editBook" ,method = RequestMethod.POST)
	public String editBook(@ModelAttribute Book book) {
		//System.out.println(book.getBookId()+" "+book.getBookName());
		
		bookService.updateBook(book);
		return "redirect:/";
	}
	
	@RequestMapping("/deleteBook")
	public String deleteBook(@RequestParam("id") int bid) {
		bookService.deleteBookById(bid);
		return "redirect:/";
	}
	
	@RequestMapping("/getEditLib")
	public ModelAndView getEditLibrary(@RequestParam("lid") int lid) {
		ModelAndView mv = new ModelAndView("EditLibrary");
		//System.out.println(lid);
		Library lib = libService.findById(lid);
		mv.addObject("library", lib);
		//System.out.println(lib.getLibraryName());
		return mv;
	}
	
	@RequestMapping(value = "/editLib" ,method = RequestMethod.POST )
	public String editLibrary(@ModelAttribute Library library) {
		libService.updateLibrary(library);
		return "redirect:/";
	}
	
	@RequestMapping("deleteLib")
	public String deleteLibrary(@RequestParam("lid") int lid) {
		libService.deleteLibrary(lid);
		return "redirect:/";
	}
	
}
